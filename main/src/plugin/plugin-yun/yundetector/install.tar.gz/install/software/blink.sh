#!/bin/sh

echo "timer" > /sys/class/leds/ds:green:usb/trigger
echo $1 > /sys/class/leds/ds:green:usb/delay_on
echo $1 > /sys/class/leds/ds:green:usb/delay_off
exit 0
