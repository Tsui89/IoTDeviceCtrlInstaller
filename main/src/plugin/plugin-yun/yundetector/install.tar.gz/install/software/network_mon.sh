#!/bin/sh

INTERVAL=5
RETRY=6
SERVER_IP=9.186.89.160
FAIL_CNT=0

while true
do
	`ping ${SERVER_IP} -c 1 -W 1 > /dev/null`
	RET=$?

	if [  ${RET} -ne 0 ]; then
		let FAIL_CNT=${FAIL_CNT}+1
		echo "`date`: Network disconneced #${FAIL_CNT}"
		if [ ${FAIL_CNT} -gt $RETRY ]; then
			echo "`date`: Network restarting..."
			/etc/init.d/network restart
			echo "`date`: Network restarted"
			let FAIL_CNT=0
		fi
	else
		let FAIL_CNT=0
	fi
	sleep $INTERVAL
done
