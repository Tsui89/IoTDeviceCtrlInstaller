#!/usr/bin/python

import sys
sys.path.insert(0, "/usr/lib/python2.7/bridge")
from bridgeclient import BridgeClient
import mosquitto
import time
import json
import uuid
import logging


def get_mac_address():
	mac=uuid.UUID(int = uuid.getnode()).hex[-12:]
	macAddr = ":".join([mac[e:e+2] for e in range(0,11,2)])
	return macAddr.upper()
                        

def on_connect(mosq, obj, rc):
#	mosq.subscribe("$SYS/#", 0)
	if rc == 0:
		logging.info("MQTT connected successfully")

def on_message(mosq, obj, msg):
	logging.info("Message received, topic: " + msg.topic + " payload: " + str(msg.payload))
	if (did != "0") and (msg.topic == commandTopic):
		handleCommandCallback(msg.payload)
	elif msg.topic == onlinePublish:
		handleOnlineCallback(msg.payload)

def on_publish(mosq, obj, mid):
	logging.debug("Data publish completed")

def on_subscribe(mosq, obj, mid, granted_qos):
	logging.info("Subscribed topic success")

def on_log(mosq, obj, level, string):
	logging.debug(string)
	
def on_disconnect(mosq, obj, rc):
	global mqttDisconnRetry;
	if rc == 0:
		logging.warning("Disconnected successfully.")
	else:
		logging.warning("Unexpected disconnected, wait for reconnecting...")
		mqttDisconnRetry = True
		

def handleCommandCallback(payload):
	pLoad = json.read(payload)
	pLoad = pLoad[0]
	commandStr = pLoad["command"]
	argumentStr = pLoad["arguments"]
	logging.info("command: " + commandStr + " argument: " + argumentStr)
	
def handleOnlineCallback(payload):
	global commandTopic
	global streamTopic
	global topicRegDone
	pLoad = json.read(payload)
	pLoad = pLoad[0]
	typeStr = pLoad["type"]
	snStr = pLoad["sn"]
	if (snStr == sn) and (typeStr == typeName):
		didStr = pLoad["did"]
		streamTopic = "/iot/dm/" + didStr + "/stream"
		commandTopic = "/iot/dm/" + didStr + "/command"
		logging.info("commandTopic: " + commandTopic)
		logging.info("streamTopic: " + streamTopic)	
		mqttc.subscribe(str(commandTopic), 0)
		topicRegDone = True




######## Main program starts here #########

serverAddr = "9.186.89.160"
serverPort = 1883
aliveTimeout = 20

onlineTopic = "/iot/dm/online"
onlinePublish = "/iot/dm/online/publish"
streamName = "PeopleDetect"
typeName = "PIR"
sn = get_mac_address()
#sn = "90:A2:DA:FA:0B:EA"
did = "0"
dataKay = "PIR"

streamTopic = ""
commandTopic = ""

mqttDisconnRetry = False

logging.basicConfig(level=logging.INFO, format='%(filename)s[line:%(lineno)d] %(asctime)s %(levelname)s: %(message)s', datefmt='[%d/%b/%Y %H:%M:%S]')
#logging.basicConfig(level=logging.INFO, format='%(filename)s[line:%(lineno)d] %(asctime)s %(levelname)s: %(message)s', datefmt='[%d/%b/%Y %H:%M:%S]', filename='./mqtt_client_arduino_yun.log')


bridgeClient = BridgeClient()
mqttc = mosquitto.Mosquitto()
mqttc.on_message = on_message
mqttc.on_connect = on_connect
mqttc.on_publish = on_publish
mqttc.on_subscribe = on_subscribe
mqttc.on_disconnect = on_disconnect
# Uncomment to enable debug messages
#mqttc.on_log = on_log

while True:

	topicRegDone = False
	try:
		while True:
			result = mqttc.connect(serverAddr, serverPort, aliveTimeout)
			if result is not True:
				logging.info("MQTT server " + serverAddr + " connected.")
				break;
			else:
				logging.warning("MQTT server " + serverAddr + " connected faied, waiting for retry...")
				time.sleep(2);

		mqttc.subscribe(onlinePublish, 0)
		time.sleep(0.3)
		onlineMessage = "{\"type\":\"" + typeName + "\",\"sn\":\"" + sn + "\"}"
		mqttc.publish(onlineTopic, onlineMessage, 0)

		while True:
			if mqttDisconnRetry:
				time.sleep(5)
				logging.warning("Prepared for reconnecting...")
				mqttDisconnRetry = False
				break
			if topicRegDone:
				sensorMsg = bridgeClient.get(dataKay)
				dict = {}
				dict["did"] = ""
				dict["sn"] = sn
				dict["cid"] = ""
				dict["streamname"] = streamName
				dict["typename"] = typeName
				dict["value"] = str(sensorMsg)
				dict["timestamp"] = "%TIMESTAMP%" 
				dictMsg = json.write(dict)
				mqttc.publish(streamTopic, dictMsg, 0)
				logging.debug("Data published: " + dictMsg)
			mqttc.loop()
			time.sleep(1)
	except:
		logging.warning("Exception triggered, wait for reconnecting...")	
		mqttDisconnRetry = False
		time.sleep(5)


