#!/bin/sh

cd python-mosquitto
python ./setup.py install
cd ..
cp ./rc.local /etc/
chmod +x /etc/rc.local
cp ./mqtt_client_arduino_yun.py /root/
cp ./network_mon.sh /root/
chmod +x /root/mqtt_client_arduino_yun.py
chmod +x /root/network_mon.sh
echo "software install complete!"
