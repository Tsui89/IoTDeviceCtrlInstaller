#!/bin/sh

cd leap_support
./leap_install.sh
cd ../software
./software_install.sh
./blink.sh 1000
