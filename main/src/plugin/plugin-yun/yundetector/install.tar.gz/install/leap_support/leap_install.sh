#!/bin/sh

opkg remove wpad-mini
opkg install ./opkg/wpa-cli_20131120-1_ar71xx.ipk
opkg install ./opkg/wpa-supplicant_20131120-1_ar71xx.ipk
opkg install ./opkg/hostapd_20131120-1_ar71xx.ipk
opkg install ./opkg/python-openssl_2.7.3-2_ar71xx.ipk

cp ./config/network /etc/config/network
cp ./config/wireless /etc/config/wireless
mkdir /etc/wpa_supplicant
cp ./config/wpa_supplicant.conf /etc/wpa_supplicant/wpa_supplicant.conf
cp ./config/network_init /etc/init.d/network
chmod +x /etc/init.d/network
echo "leap install complete!"
